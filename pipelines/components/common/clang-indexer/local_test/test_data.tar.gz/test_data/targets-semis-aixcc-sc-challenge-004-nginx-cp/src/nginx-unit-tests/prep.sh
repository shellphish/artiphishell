cp ../exploits/vuln_0${1}/*.t .
prove -j8 .
