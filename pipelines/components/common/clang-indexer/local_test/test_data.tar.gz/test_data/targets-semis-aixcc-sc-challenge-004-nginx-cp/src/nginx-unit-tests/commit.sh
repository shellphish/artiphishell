git add .
git commit -m "applied vuln_${1} unit test"
