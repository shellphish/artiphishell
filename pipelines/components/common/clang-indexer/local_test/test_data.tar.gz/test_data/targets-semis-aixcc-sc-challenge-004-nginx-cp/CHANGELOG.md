# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [1.0.2] – 2024-06-20

### Changed

- Refactored `cp_pov` to better handle default arguments, environment
  variables, harness file checks, and libfuzzer exit codes.

## [1.0.1] – 2024-06-17

### Added

- Documented the extra environment variables that are available to extend
  the default environment variables for the CP bases and harnesses. These
  were supported in CP Sandbox v3.0.0 internals, just not documented in the
  README.

## [1.0.0] – 2024-06-14

First release of the AIxCC Nginx Challenge Project, which is
compliant with CP Sandbox v3.0.0.

<!-- markdownlint-disable-file MD024 -->
