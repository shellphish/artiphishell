package jenkins;

import org.junit.Test;

public class Junit4TestsRanTest {

    @Test
    public void anything() {
        // intentionally blank.
        // we just want a test that runs with junit 4 so that if tests get skipped due to the introduction of jupiter engine we are alerted
    }

}
