Package meant to be used to collect all the useful classes that are not tests, but used in test.

Improve readability by splitting test cases and test classes.
