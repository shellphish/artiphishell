/**
 * Tests the JavaScript code.
 */
package scripts;
