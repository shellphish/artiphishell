=====================
 AMDGPU XGMI Support
=====================

.. kernel-doc:: drivers/gpu/drm/amd/amdgpu/amdgpu_xgmi.c
