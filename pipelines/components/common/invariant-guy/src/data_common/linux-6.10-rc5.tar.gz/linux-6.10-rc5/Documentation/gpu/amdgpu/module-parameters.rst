===================
 Module Parameters
===================

The amdgpu driver supports the following module parameters:

.. kernel-doc:: drivers/gpu/drm/amd/amdgpu/amdgpu_drv.c
