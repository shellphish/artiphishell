.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

=================
Memory Management
=================

.. kernel-doc:: drivers/gpu/drm/xe/xe_bo_doc.h
   :doc: Buffer Objects (BO)

Pagetable building
==================

.. kernel-doc:: drivers/gpu/drm/xe/xe_pt.c
   :doc: Pagetable building
