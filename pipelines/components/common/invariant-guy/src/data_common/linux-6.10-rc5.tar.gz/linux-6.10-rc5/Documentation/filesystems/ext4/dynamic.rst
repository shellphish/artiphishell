.. SPDX-License-Identifier: GPL-2.0

Dynamic Structures
==================

Dynamic metadata are created on the fly when files and blocks are
allocated to files.

.. include:: inodes.rst
.. include:: ifork.rst
.. include:: directory.rst
.. include:: attributes.rst
