.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

==================
Command submission
==================

.. kernel-doc:: drivers/gpu/drm/xe/xe_exec.c
   :doc: Execbuf (User GPU command submission)
