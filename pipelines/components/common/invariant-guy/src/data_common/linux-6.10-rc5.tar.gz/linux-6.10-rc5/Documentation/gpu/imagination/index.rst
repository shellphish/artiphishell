=======================================
drm/imagination PowerVR Graphics Driver
=======================================

.. kernel-doc:: drivers/gpu/drm/imagination/pvr_drv.c
   :doc: PowerVR (Series 6 and later) and IMG Graphics Driver

Contents
========
.. toctree::
   :maxdepth: 2

   uapi
