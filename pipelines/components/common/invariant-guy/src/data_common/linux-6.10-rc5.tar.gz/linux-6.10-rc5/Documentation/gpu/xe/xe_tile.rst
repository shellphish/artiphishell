.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

==================
Multi-tile Devices
==================

.. kernel-doc:: drivers/gpu/drm/xe/xe_tile.c
   :doc: Multi-tile Design

Internal API
============

.. kernel-doc:: drivers/gpu/drm/xe/xe_tile.c
   :internal:
