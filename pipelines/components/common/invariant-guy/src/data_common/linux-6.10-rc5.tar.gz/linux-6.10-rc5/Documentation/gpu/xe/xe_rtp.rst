.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

=========================
Register Table Processing
=========================

.. kernel-doc:: drivers/gpu/drm/xe/xe_rtp.c
   :doc: Register Table Processing

Internal API
============

.. kernel-doc:: drivers/gpu/drm/xe/xe_rtp_types.h
   :internal:

.. kernel-doc:: drivers/gpu/drm/xe/xe_rtp.h
   :internal:

.. kernel-doc:: drivers/gpu/drm/xe/xe_rtp.c
   :internal:
