.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

========================
Runtime Power Management
========================

.. kernel-doc:: drivers/gpu/drm/xe/xe_pm.c
   :doc: Xe Power Management

Internal API
============

.. kernel-doc:: drivers/gpu/drm/xe/xe_pm.c
   :internal:
