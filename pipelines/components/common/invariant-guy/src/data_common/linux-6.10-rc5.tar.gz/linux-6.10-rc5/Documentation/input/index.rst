===================
Input Documentation
===================

Contents:

.. toctree::
   :maxdepth: 2

   input_uapi
   input_kapi
   devices/index

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
