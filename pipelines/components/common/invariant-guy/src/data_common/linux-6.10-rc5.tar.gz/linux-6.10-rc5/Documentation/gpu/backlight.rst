=================
Backlight support
=================

.. kernel-doc:: drivers/video/backlight/backlight.c
   :doc: overview

.. kernel-doc:: include/linux/backlight.h
   :internal:

.. kernel-doc:: drivers/video/backlight/backlight.c
   :export:
