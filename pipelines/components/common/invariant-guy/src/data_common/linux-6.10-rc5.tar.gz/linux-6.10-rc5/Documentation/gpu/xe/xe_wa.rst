.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

====================
Hardware workarounds
====================

.. kernel-doc:: drivers/gpu/drm/xe/xe_wa.c
   :doc: Hardware workarounds

Internal API
============

.. kernel-doc:: drivers/gpu/drm/xe/xe_wa.c
   :internal:
