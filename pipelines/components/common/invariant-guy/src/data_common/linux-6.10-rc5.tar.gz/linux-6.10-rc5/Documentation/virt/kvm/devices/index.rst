.. SPDX-License-Identifier: GPL-2.0

=======
Devices
=======

.. toctree::
   :maxdepth: 2

   arm-vgic-its
   arm-vgic
   arm-vgic-v3
   mpic
   s390_flic
   vcpu
   vfio
   vm
   xics
   xive
