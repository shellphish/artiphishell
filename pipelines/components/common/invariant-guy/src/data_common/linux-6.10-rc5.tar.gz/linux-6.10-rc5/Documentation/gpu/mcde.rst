.. SPDX-License-Identifier: GPL-2.0

=======================================================
 drm/mcde ST-Ericsson MCDE Multi-channel display engine
=======================================================

.. kernel-doc:: drivers/gpu/drm/mcde/mcde_drv.c
   :doc: ST-Ericsson MCDE Driver
