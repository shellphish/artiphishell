.. SPDX-License-Identifier: GPL-2.0

===============================
The Linux kernel firmware guide
===============================

This section describes the ACPI subsystem in Linux from firmware perspective.

.. toctree::
   :maxdepth: 1

   acpi/index

