.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

==============================================
GT Multicast/Replicated (MCR) Register Support
==============================================

.. kernel-doc:: drivers/gpu/drm/xe/xe_gt_mcr.c
   :doc: GT Multicast/Replicated (MCR) Register Support

Internal API
============

TODO
