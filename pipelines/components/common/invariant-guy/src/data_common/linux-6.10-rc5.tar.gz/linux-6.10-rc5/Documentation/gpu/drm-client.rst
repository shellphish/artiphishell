=================
Kernel clients
=================

.. kernel-doc:: drivers/gpu/drm/drm_client.c
   :doc: overview

.. kernel-doc:: include/drm/drm_client.h
   :internal:

.. kernel-doc:: drivers/gpu/drm/drm_client.c
   :export:

.. kernel-doc:: drivers/gpu/drm/drm_client_modeset.c
   :export:
