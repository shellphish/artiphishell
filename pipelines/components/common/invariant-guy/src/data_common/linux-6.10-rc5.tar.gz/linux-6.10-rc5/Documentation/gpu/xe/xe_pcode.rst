.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

=====
Pcode
=====

.. kernel-doc:: drivers/gpu/drm/xe/xe_pcode.c
   :doc: PCODE

Internal API
============

.. kernel-doc:: drivers/gpu/drm/xe/xe_pcode.c
   :internal:
