.. SPDX-License-Identifier: GPL-2.0

===================================
ext4 Data Structures and Algorithms
===================================

.. toctree::
   :maxdepth: 6
   :numbered:

   about
   overview
   globals
   dynamic
