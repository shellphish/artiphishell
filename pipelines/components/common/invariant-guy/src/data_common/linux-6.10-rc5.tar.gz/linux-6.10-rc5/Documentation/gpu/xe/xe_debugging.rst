.. SPDX-License-Identifier: (GPL-2.0+ OR MIT)

=========
Debugging
=========

.. kernel-doc:: drivers/gpu/drm/xe/xe_assert.h
