================
Recursion issues
================

issue #1
--------

.. literalinclude:: Kconfig.recursion-issue-01
   :language: kconfig

issue #2
--------

.. literalinclude:: Kconfig.recursion-issue-02
   :language: kconfig
